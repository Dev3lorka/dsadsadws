Resource pack MagCode (Minecraft 1.21.4)
Modele: magcode:<id> (plugin ustawia je automatycznie przez item_model).
Tekstury 32x32 w assets/magcode/textures/item/.
